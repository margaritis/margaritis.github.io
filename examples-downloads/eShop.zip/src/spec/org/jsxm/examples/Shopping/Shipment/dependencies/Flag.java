package generated;

public class Flag {
	static private boolean flag = false;
	public static boolean isSet() { return flag; }
	public static void toggle() { if (flag) flag = false; else flag = true; }

	public static void main(String a[]) {
					if (Flag.isSet()) {
									System.out.println("Flag set");
									Flag.toggle();
					}
					else {
									System.out.println("Flag not set");
									Flag.toggle();
					}
					System.out.println("Final: " + Flag.isSet());
	}
}
