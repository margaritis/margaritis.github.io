package jsxm.testAdapters;

import org.jsxm.examples.bank.AccountDebit;

public class AccountDebitAdapter{

	AccountDebit object=new AccountDebit();

	public String deposit(int amount){ 
		try { 
			object.deposit(amount);
		} catch (Exception e) {
			return "depositError";
		}
		return "depositOut";
	}

	public String withdraw(int amount){ 
		try {
			object.withdraw(amount);
		} catch (Exception e) {
			return "withdrawError";
		}
		return "withdrawOut";
	}

}

