package org.jsxm.examples.bank;


public class AccountDebit{

	private int balance=0;

	public void deposit(int amount){ 
		balance = balance + amount;
	}

	public void withdraw(int amount){ 
		if (balance < 0 )
			throw new RuntimeException();
		balance = balance - amount;
	}
	


}

