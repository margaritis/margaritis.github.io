package org.jsxm.examples.Calculator;

public class CalcPlusMinus {
	private int number = 0;
	private int total = 0;

	private static final int ADD = 0;
	private static final int SUB = 1;
	private static final int EQ = 2;
	private int op = EQ;

	private boolean firstDigit = true;
	private boolean equalDone = false;
	public int d(int x) {
		if(firstDigit) {
			if(x < 1 || x > 9)
				throw new RuntimeException("d1Err");
		}
		if(x < 0 || x > 9)
			throw new RuntimeException("dNErr");
		if (firstDigit)	{
			number = x;
			firstDigit = false;
		} else 
			number = 10*number + x;
		equalDone = false;
		return number;
	}

	public int eq() {
		if (number == 0 || equalDone)
			throw new RuntimeException("eqErr");
		calc();
		op = EQ;
		number = total;
		total = 0;
		firstDigit = true;
		equalDone = true;
		return number;
	}

	public int plus() {
		// added && !equalDone after discovered with a k=3 test

		//assertEquals("dOut_7", obj.d(7));
		//assertEquals("eqOut_7", obj.eq());
		//assertEquals("minusOut_7", obj.minus());
		//assertEquals("eqErr", obj.eq());
		//assertEquals("dOut_7", obj.d(7));
		//assertEquals("eqOut_0", obj.eq());
		//assertEquals("plusOut_0", obj.plus()); // was plusErr

		// discovery was a concidence: 7 - 7 gives 0 and plus is allowed because
		// this is a result of a calc.

		if (number == 0 && !equalDone)
			throw new RuntimeException("plusErr");
		calc();
		op = ADD;
		number = 0;
		firstDigit = true;
		equalDone = false;
		return total;
	}

	public int minus() {
		// see comment above in plus
		if (number == 0 && ! equalDone)
			throw new RuntimeException("minusErr");
		calc();
		op = SUB;
		number = 0;
		firstDigit = true;
		equalDone = false;
		return total;
	}

	private void calc() {
		if (op == ADD) 
			total = total + number;
		else if (op == SUB)
			total = total - number;
		else
			total = number;
	}
}
