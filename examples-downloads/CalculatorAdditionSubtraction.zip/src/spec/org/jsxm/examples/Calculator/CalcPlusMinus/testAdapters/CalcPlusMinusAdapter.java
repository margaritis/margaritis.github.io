package jsxm.testAdapters;

import org.jsxm.examples.Calculator.CalcPlusMinus;

public class CalcPlusMinusAdapter {
	private CalcPlusMinus c = new CalcPlusMinus();

	public String d(int x) {
		try {
			return "dOut_"+c.d(x);
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public String eq() {
		try {
			return "eqOut_"+c.eq();
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public String plus() {
		try {
			return "plusOut_"+c.plus();
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	public String minus() {
		try {
			return "minusOut_"+c.minus();
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}
