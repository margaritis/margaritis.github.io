package jsxm.testAdapters;

import org.jsxm.examples.Calculator.Calc;

public class CalcAdapter {
	private Calc c = new Calc();

	public String d(int x) {
		try {
			return "dOut_"+c.d(x);
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public String eq() {
		try {
			return "eqOut_"+c.eq();
		} catch (Exception e) {
			return e.getMessage();
		}
	}

	public String plus() {
		try {
			return "plusOut_"+c.plus();
		} catch (Exception e) {
			return e.getMessage();
		}
	}
}
