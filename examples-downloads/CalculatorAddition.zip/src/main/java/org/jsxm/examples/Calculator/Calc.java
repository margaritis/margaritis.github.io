package org.jsxm.examples.Calculator;

public class Calc {
	private int number = 0;
	private int total = 0;

	private boolean firstDigit = true;
	private boolean equalDone = false;
	public int d(int x) {
		if(firstDigit) {
			if(x < 1 || x > 9)
				throw new RuntimeException("d1Err");
		}
		if(x < 0 || x > 9)
			throw new RuntimeException("dNErr");
		if (firstDigit)	{
			number = x;
			firstDigit = false;
		} else 
			number = 10*number + x;
		equalDone = false;
		return number;
	}

	public int eq() {
		if (number == 0 || equalDone)
			throw new RuntimeException("eqErr");
		number = number + total;
		total = 0;
		firstDigit = true;
		equalDone = true;
		return number;
	}

	public int plus() {
		if (number == 0)
			throw new RuntimeException("plusErr");
		total = number + total;
		number = 0;
		firstDigit = true;
		equalDone = false;
		return total;
	}

}
