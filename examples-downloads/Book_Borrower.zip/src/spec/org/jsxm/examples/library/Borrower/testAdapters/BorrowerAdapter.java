package jsxm.testAdapters;

import org.jsxm.examples.library.*;

public class BorrowerAdapter {
	private Borrower borrower = new Borrower(51);
	
	public Borrower getBorrower() {return borrower;}

	public String borrowBook(BookAdapter book) {
		try {
			borrower.borrowBook(book.getBook());
		} catch (Exception e) {
			return e.getMessage();
		}
		return "borrowBookOut";
	}
	public String returnBook() {
		try {
			borrower.returnBook();
		} catch (Exception e) {
			return "returnBook_Error";
		}
		return "returnBookOut";
	}


	public String canBorrow() {
		return "canBorrowOut_" + borrower.canBorrow();
	}

}
