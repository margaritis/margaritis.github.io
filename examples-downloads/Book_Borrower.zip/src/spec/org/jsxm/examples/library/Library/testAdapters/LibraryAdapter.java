package jsxm.testAdapters;

import org.jsxm.examples.library.*;

public class LibraryAdapter {
	private Library library = new Library();
	
	public Library getLibrary() {return library;}

	public String addBook(int book) {
		try {
			library.addBook(book);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "addBookOut";
	}

	public String addBorrower(int borrower) {
		try {
			library.addBorrower(borrower);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "addBorrowerOut";
	}
	
	public String borrowBook(int borrower, int book) {
		try {
			library.borrowBook(borrower, book);
		} catch (Exception e) {
			return e.getMessage();
		}
		return "borrowBookOut";
	}
	public String returnBook(int borrower) {
		try {
			library.returnBook(borrower);
		} catch (Exception e) {
			return "returnBook_Error";
		}
		return "returnBookOut";
	}

}
