package jsxm.testAdapters;

import org.jsxm.examples.library.Book;

public class BookAdapter {

	private Book book = new Book(11);

	public Book getBook() {
		return book;
	}
	
	public String isAvailable() {
		return "isAvailableOut_"+ book.isAvailable();
	}

	public String setBorrowed() {
		try {
			book.setBorrowed();
		} catch (Exception e) {
			return "setBorrowed_Error";
		}
		return "setBorrowedOut";
	}

	public String release() {
		try {
			book.release();
		} catch (Exception e) {
			return "release_Error";
		}
		return "releaseOut";
	}
}
