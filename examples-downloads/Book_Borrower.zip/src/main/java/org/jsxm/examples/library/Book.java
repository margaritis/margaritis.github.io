package org.jsxm.examples.library;

public class Book{

	private int bookId;
	
	private boolean available = true;

	public Book(int bookId) {
		this.bookId = bookId;
	}
	
	public boolean isAvailable() {
		return available;
	}

	public void setBorrowed() {
		if ( available ) {
			available = false;
		}
		else
			throw new RuntimeException();
	}

	public void release() {
		if (! available ) {
			available = true;
		}
		else
			throw new RuntimeException();
	}
}