package org.jsxm.examples.library;

import java.util.HashMap;
import java.util.Map;

public class Library {
	Map<Integer, Book> books;
	Map<Integer, Borrower> borrowers;
	
	public Library() {
		books = new HashMap<Integer, Book>();
		borrowers = new HashMap<Integer, Borrower>();
		
		addBook(11);
		addBook(12);
		addBook(13);
		
		addBorrower(51);
		addBorrower(52);
		addBorrower(53);
	}
	
	public void addBook(int bookId) {
		books.put(new Integer(bookId), new Book(bookId));
	}

	public void addBorrower(int borrowerId) {
		borrowers.put(new Integer(borrowerId), new Borrower(borrowerId));
	}

	public void borrowBook(int borrowerId, int bookId) {
		Book book = (Book) books.get(new Integer(bookId));
		Borrower borrower = (Borrower) borrowers.get(new Integer(borrowerId));
		
		borrower.borrowBook(book);
	}

	public void returnBook(int borrowerId) {
		Borrower borrower = (Borrower) borrowers.get(new Integer(borrowerId));

		borrower.returnBook();
	}

}
