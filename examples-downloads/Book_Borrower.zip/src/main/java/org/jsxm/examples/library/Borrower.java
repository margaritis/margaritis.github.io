package org.jsxm.examples.library;

public class Borrower {
	
	private int borrowerId;
	
	private Book book = null;

	public Borrower(int borrowerId) {
		this.borrowerId = borrowerId;
	}
	
	public void borrowBook(Book book) {
		if (book.isAvailable() && this.book== null) {
			this.book = book;
			book.setBorrowed();
		} else if (this.book != null)
			throw new RuntimeException("borrowBook_CannotBorrow");
		else
			throw new RuntimeException("borrowBook_NotAvailable");

	}
	public void returnBook() {
		if (book != null) {
			book.release();
			book = null;
		}
		else
					throw new RuntimeException();

	}


	public boolean canBorrow() {

		return (book == null);
	}

}