package jsxm.testAdapters;
import org.jsxm.examples.Bank.Account2;

public class Account2Adapter {

	Account2 account = new Account2();

	public String open() {
		try {
			account.open();
		} catch (Exception e) {
			return "openError";
		}
		return "openOut";
	}

	public String close() {
		try {
			account.close();
		} catch (Exception e) {
			return "closeError";
		}
		return "closeOut";
	}

	public String deposit(int x) {
		try {
			account.deposit(x);
		} catch (Exception e) {
			return "depositError";
		}
		return "depositOut_" + x;
	}

	public String withdraw(int x) {
		try {
			account.withdraw(x);
		} catch (Exception e) {
			return "withdrawError";
		}
		return "withdrawOut_" + x;
	}

}
