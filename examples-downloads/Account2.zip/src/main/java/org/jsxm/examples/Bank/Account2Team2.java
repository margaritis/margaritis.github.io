package org.jsxm.examples.Bank;

public class Account2Team2 {
    
    public final static String INACTIVESTATE = "inactive";
    public final static String ACTIVESTATE = "active";
    public final static String CLOSEDSTATE = "closed";
    
    public int balance;
    public String state;
    
    public Account2Team2() {
        state = INACTIVESTATE;
        balance = 0;
    }
    
    public void open() {
        if (state == INACTIVESTATE)
            state = ACTIVESTATE;
        else if (state == CLOSEDSTATE)
            throw new RuntimeException();
        else
            throw new RuntimeException();
    }
    
    public void close() {
        if (state == ACTIVESTATE && balance == 0) {
            state=CLOSEDSTATE;
        }
        
        else
            throw new RuntimeException();
    }
    
    public void deposit(int x) {
        if (state == ACTIVESTATE) {
            if (x > 0)
                balance = balance + x;
            else
                throw new RuntimeException();
        } else
            throw new RuntimeException();
    }
    
    public void withdraw(int x) {
        
        if (state == ACTIVESTATE && balance >= x) {
            if (x > 0)
                balance = balance - x;
            else
                throw new RuntimeException();
        } else
            throw new RuntimeException();
    }
    
}
