package org.jsxm.examples.Bank;

public class Account2Team1 {

    private int balance;
    private String state;

    public Account2Team1(){
        balance=0;
        state="";
    }

    public void open(){

        if(state=="inactive")
        {
            balance=0;

        }
        else
        {
            throw new RuntimeException();
        }

    }

    public void close(){
        if (state=="active")
            balance=0;

    }

    public void deposit(int x){

        if(state=="active")
            balance=balance+x;
    }

    public void withdraw(int x){
        if(state=="active")
            balance=balance-x;
    }
}
