package jsxm.testAdapters;
import org.jsxm.examples.automaton.Automaton;
/**
*
* @author Konstantinos Margaritis
*
*/
public class AutomatonAdapter{

	/**
	* New automaton for testing
	*/
	Automaton object=new Automaton();

	/**
	* Starting the automaton
	* @return
	*/
	public String startAutomaton(){ 
		try { 
			object.startAutomaton();
		} catch (Exception e) {
			return "startAutomaton_Error";
		}
		return "startOut";
	}

	/**
	* Stopping the automaton
	* @return
	*/
	public String stopAutomaton(){ 
		try {
			object.stopAutomaton();
		} catch (Exception e) {
			return "stopAutomaton_Error";
		}
		return "stopOut";
	}
	/**
	* Reseting the automaton
	* @return
	*/
	public String resetAutomaton(){
		try {
			object.resetAutomaton();
		} catch (Exception e) {
			return "resetAutomaton_Error";
		}
		return "resetOut";
	}
}

