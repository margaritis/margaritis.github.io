package org.jsxm.examples.automaton;

import org.jsxm.examples.exceptions.AutomatonNotStartedException;
import org.jsxm.examples.exceptions.NonResetableAutomatonException;
import org.jsxm.examples.exceptions.NonStartableAutomatonException;

/**
 * 
 * @author Konstantinos Margaritis
 * 
 */
public class Automaton {
    
    /**
     * Variable for declaring whether the automaton has already started
     */
    private boolean isStarted = false;
    
    /**
     * Variable for declaring whether the automaton has been stopped
     */
    private boolean isStopped = false;
    
    /**
     * Starting the automaton
     */
    public void startAutomaton() {
        if (!isStarted && !isStopped) {
            isStarted = true;
            isStopped = false;
        } else {
            throw new NonStartableAutomatonException("Not able to start Automaton");
        }
    }
    
    /**
     * Stopping the automaton
     */
    public void stopAutomaton() {
        if (isStarted) {
            isStarted = false;
            isStopped = true;
        } else {
            throw new AutomatonNotStartedException("Automaton is not started");
        }
    }
    
    /**
     * Resetting the automaton
     */
    public void resetAutomaton() {
        if (isStarted) {
            isStarted = false;
        } else if (isStopped) {
            isStopped = false;
        } else {
            throw new NonResetableAutomatonException("Not able to reset the Automaton");
        }
    }
}
