/**
 * JSXM Maven PLugin CONFIDENTIAL
 * 
 *  __________________
 * 
 * Unpublished Copyright © 2012-2013 Konstantinos Margaritis, 
 * All Rights Reserved.
 * 
 * NOTICE:  All information contained herein is, and remains the property of Konstantinos Margaritis . 
 *
 * The intellectual and technical concepts contained herein are proprietary to the owner
 * Konstantinos Margaritis and may be covered by U.S and Foreign Patents, patents in process, 
 * and are protected by trade secret or copyright law. Dissemination of this information or 
 * reproduction of this material is strictly forbidden unless prior written permission is
 * obtained from Konstantinos Margaritis. Access to the source code contained herein is hereby 
 * forbidden to anyone except the owner.Confidentiality and Non-disclosure agreements 
 * explicitly covering such access.
 *
 * The copyright notice above does not evidence any actual or intended publication 
 * or disclosure  of  this source code, which includes information that is confidential 
 * and/or proprietary, and is a trade secret, of  Konstantinos Margaritis. ANY REPRODUCTION, 
 * MODIFICATION, DISTRIBUTION, PUBLIC  PERFORMANCE, OR PUBLIC DISPLAY OF OR THROUGH USE  OF 
 * THIS  SOURCE CODE  WITHOUT  THE EXPRESS WRITTEN CONSENT OF Konstantinos Margaritis IS STRICTLY PROHIBITED, 
 * AND IN VIOLATION OF APPLICABLE LAWS AND INTERNATIONAL TREATIES.  THE RECEIPT OR POSSESSION OF  
 * THIS SOURCE CODE AND/OR RELATED INFORMATION DOES NOT CONVEY OR IMPLY ANY RIGHTS  
 * TO REPRODUCE, DISCLOSE OR DISTRIBUTE ITS CONTENTS, OR TO MANUFACTURE, USE, OR SELL 
 * ANYTHING THAT IT  MAY DESCRIBE, IN WHOLE OR IN PART.  
 * 
 */
package org.jsxm.examples.exceptions;

import java.net.MalformedURLException;
import java.net.URL;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author Konstantinos Margaritis
 *
 */
public class NonStartableAutomatonException extends RuntimeException{
    
    /**
     * 
     */
    private final Logger logger = (Logger) LoggerFactory.getLogger(this.getClass());
    
    /**
     * @param message
     */
    public NonStartableAutomatonException(String message) {
        super(message);
        logger.error("For more information about the errors and possible solutions, please refer to the following article:");
        try {
            logger.error(""
                    + new URL("http://www.jsxm.org/wiki/jsxmMavenPlugin/RuntimeExceptions/"
                            + this.getClass().getSimpleName()));
        } catch (MalformedURLException e) {
            logger.error("Url of RuntimeException " + this.getClass().getSimpleName() + "is malformed", e);
        }
    }
    
    /**
     * @param cause
     */
    public NonStartableAutomatonException(Throwable cause) {
        super(cause);
        logger.error("For more information about the errors and possible solutions, please refer to the following article:");
        try {
            logger.error(""
                    + new URL("http://www.jsxm.org/wiki/jsxmMavenPlugin/RuntimeExceptions/"
                            + this.getClass().getSimpleName()));
        } catch (MalformedURLException e) {
            logger.error("Url of RuntimeException " + this.getClass().getSimpleName() + "is malformed", e);
        }
    }
    
    /**
     * @param message
     * @param cause
     */
    public NonStartableAutomatonException(String message, Throwable cause) {
        super(message, cause);
        logger.error("For more information about the errors and possible solutions, please refer to the following article:");
        try {
            logger.error(""
                    + new URL("http://www.jsxm.org/wiki/jsxmMavenPlugin/RuntimeExceptions/"
                            + this.getClass().getSimpleName()));
        } catch (MalformedURLException e) {
            logger.error("Url of RuntimeException " + this.getClass().getSimpleName() + "is malformed", e);
        }
    }
}
